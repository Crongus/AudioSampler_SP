



// algorithm for getting values from the keypad and translating them to the actuall characters on the keys
unsigned char keypad_scan();
