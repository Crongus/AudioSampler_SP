##  Lab Report ##

What is something cool you did in this lab?
-----------
Your answer: 
I made the '*' key backspace. also, holding down the key will register multiple inputs. Also, if it flows over the right side of the screen, it feeds them in from the left and deletes the right side

Post-lab Questions
-------

* Answers to Question 1: Can the scan algorithm detect all keys pressed when multiple keys are pressed? (Hint:
ghosting or ghost key)

No, it will prioritize the keys further right and then further down. So if '4' and '5' are pressed simultaniously only '5' will be registered. and if '1' and '7' are pressed, only '7' will be registered. also, if '2' and '7' are pressed, only '2' will be registered

* Answers to Question 2:

* Answers to Question 3 (if appliable):

* Answers to Question 4 (if appliable):


Suggestions and Comments
-------

* Do you have comments or suggestions for the lab and course?


* Do you have comments or suggestions for the textbook and lab handouts? Any typos or errors?



Lab Credits
-------
Did you received any help from someone other than the instructor and lab teaching assistants?

Your answer: 


